
// Basic show/hide toggles for answers and expandable notes
document.addEventListener('click', (e)=>{
  const btn = e.target.closest('[data-toggle]');
  if(!btn) return;
  const id = btn.getAttribute('data-toggle');
  const target = document.getElementById(id);
  if(target){
    const on = target.style.display === 'block';
    target.style.display = on ? 'none' : 'block';
  }
});
