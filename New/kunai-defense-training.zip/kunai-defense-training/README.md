# Kunai Defense Training — Split Project (Vanilla ES Modules)

**Structure**
```
kunai-defense-training/
├─ index.html               # Canvas + DOM panels
├─ styles/
│  └─ style.css             # Theme/UI
├─ src/
│  ├─ main.js               # Orchestrator (game loop, draw, UI wiring)
│  ├─ data.js               # Jutsu/Armor/Changelog/Tips JSON
│  ├─ save.js               # LocalStorage save/load
│  ├─ assetKit.js           # Placeholder SFX (WebAudio)
│  ├─ input.js              # Keyboard + mobile controls
│  └─ util.js               # Small helpers
└─ assets/
   └─ placeholders/README.md
```

Open `index.html` via a local server (recommended due to ES modules). For example:

```bash
python -m http.server 8080
# then visit http://localhost:8080/kunai-defense-training/
```

> No external libraries. All logic is vanilla JS. Replace placeholder shapes and SFX as you add real assets.

**Notes**
- Saves under `localStorage` key `kdt_save_v010`.
- TP, unlocks, options, and loadout persist.
- Difficulty seed is a label for now; plug a seeded RNG later.
- Drills mode is a locked overlay stub.

**Swap-in points**
- VFX/Sprites: search for `drawProjectile`, `drawPlayer` in `src/main.js`.
- SFX: replace in `src/assetKit.js`.
- Balancing: search for `tierParams`, `Patterns.*`, and DATA in `src/data.js`.
