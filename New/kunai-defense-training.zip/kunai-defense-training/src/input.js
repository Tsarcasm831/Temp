export const Input = { left:false,right:false,dash:false,j1:false,j2:false,sub:false,pause:false };
function key(e,down){
  const k=e.key.toLowerCase();
  if(["arrowleft","a"].includes(k)) Input.left=down;
  if(["arrowright","d"].includes(k)) Input.right=down;
  if(k===" ") Input.dash=down;
  if(k==="q") Input.j1=down;
  if(k==="e") Input.j2=down;
  if(k==="r" && down) Input.sub=true;
  if(k==="escape" && down) Input.pause=true;
}
export function setupInput(stage){
  addEventListener('keydown',e=>key(e,true));
  addEventListener('keyup',e=>key(e,false));
  const mob = id=>document.getElementById(id);
  function bindHold(btn, prop){
    let t; const on=()=>{Input[prop]=true; clearInterval(t); t=setInterval(()=>Input[prop]=true, 50)};
    const off=()=>{clearInterval(t); Input[prop]=false};
    btn.addEventListener('touchstart',e=>{e.preventDefault();on()});
    btn.addEventListener('touchend',e=>{e.preventDefault();off()});
    btn.addEventListener('mousedown',on); btn.addEventListener('mouseup',off); btn.addEventListener('mouseleave',off);
  }
  bindHold(mob('mLeft'),'left'); bindHold(mob('mRight'),'right');
  bindHold(mob('mJ1'),'j1'); bindHold(mob('mJ2'),'j2');
  bindHold(mob('mDash'),'dash');
  mob('mPause').addEventListener('click',()=>{Input.pause=true});
  // Swipe up = dash
  let sx=0,sy=0;
  stage.addEventListener('touchstart',e=>{const t=e.changedTouches[0]; sx=t.clientX; sy=t.clientY;});
  stage.addEventListener('touchend',e=>{const t=e.changedTouches[0]; const dy=sy-t.clientY; if(dy>40) Input.dash=true;});
}
