// Kunai Defense Training — main orchestrator
import { DATA } from './data.js';
import { SAVE_KEY, defaults, loadSave, save } from './save.js';
import { makeAssetKit } from './assetKit.js';
import { Input, setupInput } from './input.js';
import { clamp, lerp, randRange, now } from './util.js';

// Canvas / Renderer
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
let DPR = Math.max(1, Math.min(2, window.devicePixelRatio||1));
function resize(){ const w=canvas.clientWidth, h=canvas.clientHeight; canvas.width=w*DPR; canvas.height=h*DPR; ctx.setTransform(DPR,0,0,DPR,0,0); }
addEventListener('resize', resize); resize();

// Save
const saveState = loadSave();
const AssetKit = makeAssetKit(()=>saveState.options);

// Input (desktop + mobile)
setupInput(document.getElementById('stage'));

// World constants
const WORLD={ w:960, h:540, ground:500 };
const COLORS={ hp:'#6ee7b7', chakra:'#60a5fa', cooldown:'#fbbf24', dome:'rgba(202,162,90,0.15)' };

// Game state machine
const State = { MENU:0, LOADOUT:1, OPTIONS:2, PLAY:3, PAUSE:4, GAMEOVER:5, CHANGELOG:6, CREDITS:7 };
let game={ state:State.MENU, time:0, tierTime:0, volleyTime:0, rngSeed:saveState.options.seed||'normal', paused:false, slowFactor:1 };

function setSeed(seed){ game.rngSeed=seed; }

// Player
const player = {
  x: WORLD.w*0.5, y: WORLD.ground, w:22, h:28, vx:0, ax:0, speed:180, maxSpeed:260,
  hp:100, maxHp:100, chakra:100, maxChakra:100, chakraRegen:12, iTimer:0,
  dashCD:0, dashI:0, dashSpeed:540, dashDur:0.16, dashActive:false,
  style:0, nearMissTimer:0, invFlash:0,
  j1:null, j2:null, armor:DATA.armor[0],
  subArmed:false, subTimer:0,
};

function equipFromSave(){
  const j1=DATA.jutsu.find(j=>j.id===saveState.loadout.j1)||null;
  const j2=DATA.jutsu.find(j=>j.id===saveState.loadout.j2)||null;
  const ar=DATA.armor.find(a=>a.id===saveState.loadout.armor)||DATA.armor[0];
  player.j1=j1; player.j2=j2; player.armor=ar;
}
equipFromSave();

// Projectiles & pool
const PTYPE = { KUNAI:0, SHURIKEN:1, HEAVY:2, PAPER:3, ELITE:4, AOE:5, CLONE:6 };
const projectiles=[]; const pool=[];
function spawn(p){ const o=pool.pop()||{}; Object.assign(o,{active:true, ...p}); projectiles.push(o); return o; }
function resetProjectiles(){ projectiles.length=0; pool.length=0; }

let clones=[];

const spawner={ time:0, rate:1.2, accel:0, next:0, tier:0, level:0 };
function tierParams(t){ const speedMod = 1 + t*0.12; const density = 1 + t*0.2; const eliteChance = Math.min(0.05 + t*0.03, 0.35); return {speedMod,density,eliteChance,heavyChance:Math.min(0.04+t*0.03,0.35)}; }

const Patterns={
  randomRain(m){ for(let i=0;i<m;i++){ spawnKunai(randRange(20,WORLD.w-20), -30, randRange(160,220)); } },
  rows(m){ const rows=2+Math.floor(m/8); for(let r=0;r<rows;r++){ const y=-30 - r*40; for(let x=40;x<WORLD.w;x+=40){ spawnKunai(x,y,200);} } },
  sine(m){ const n=10+Math.floor(m*0.6); const amp=140; const baseV=180; for(let i=0;i<n;i++){ const x= WORLD.w*0.5 + Math.sin((i/3))*amp; spawnKunai(x,-i*24, baseV+ i); } },
  aimedBurst(m){ const n=8+Math.floor(m*0.4); for(let i=0;i<n;i++){ const x=randRange(20,WORLD.w-20); const t=player.x; const dx=t-x; spawn({type:PTYPE.KUNAI,x,y:-20,w:6,h:18,vy:200,vx:dx*0.25, dmg:14}); } },
  shurikenBurst(m){ const clusters=3+Math.floor(m/6); for(let c=0;c<clusters;c++){ const cx=randRange(60,WORLD.w-60); for(let k=0;k<5;k++){ spawn({type:PTYPE.SHURIKEN,x:cx+randRange(-20,20),y:-20,w:14,h:14,vy:200+randRange(-20,20),vx:randRange(-70,70),dmg:10,rot:randRange(0,Math.PI)});} } },
  meteor(m){ const n=Math.min(1+Math.floor(m/10),3); for(let i=0;i<n;i++){ const x=randRange(60,WORLD.w-60); spawnHeavy(x); } AssetKit.sfx.gong(); },
  eliteCurve(m){ const n=6+Math.floor(m*0.6); for(let i=0;i<n;i++){ const x=randRange(20,WORLD.w-20); spawn({type:PTYPE.ELITE,x,y:-30,w:6,h:18,vy:200,vx:0, curve:randRange(0.5,1.2), dmg:16, color:'#ff6b6b'}); } },
};

function spawnKunai(x,y,vy=200){ spawn({type:PTYPE.KUNAI,x,y,w:6,h:18,vy,dmg:12}); }
function spawnHeavy(x){ spawn({type:PTYPE.HEAVY,x,y:-40,w:24,h:24,vy:120,dmg:35,shadowY:WORLD.ground-6, whistle:true}); }
function spawnPaper(x){ spawn({type:PTYPE.PAPER,x,y:-28,w:8,h:18,vy:190,dmg:22,armed:false, fuse:1.2}); }

function waveController(dt){
  spawner.time += dt; game.tierTime += dt; game.volleyTime += dt;
  if (game.tierTime>=20){ spawner.tier++; game.tierTime=0; }
  const t = tierParams(spawner.tier);
  if (spawner.time>=spawner.next){
    spawner.time=0; const m = Math.floor(6 * t.density);
    const pick = Math.random();
    if(pick<0.25) Patterns.randomRain(m);
    else if(pick<0.45) Patterns.rows(m);
    else if(pick<0.63) Patterns.aimedBurst(m);
    else if(pick<0.80) Patterns.sine(m);
    else if(pick<0.92) Patterns.shurikenBurst(m);
    else Patterns.eliteCurve(m);
    spawner.next = Math.max(0.8, 1.6 - spawner.tier*0.08);
    if(Math.random()<t.heavyChance) Patterns.meteor(1+spawner.tier);
    if(Math.random()<0.35) for(let i=0;i<2;i++) spawnPaper(randRange(40,WORLD.w-40));
  }
  if (game.volleyTime>=60){ game.volleyTime=0; AssetKit.sfx.gong(); Patterns.sine(12); Patterns.aimedBurst(8); }
}

// Jutsu System
const JutsuSystem = {
  cooldowns: new Map(),
  timers: new Map(),
  use(j){ if(!j) return false; const key=j.id; const cd=this.cooldowns.get(key)||0; if(cd>0) return false; if(player.chakra<j.chakraCost) return false; player.chakra=Math.max(0,player.chakra-j.chakraCost); this.cooldowns.set(key,j.cooldown); this.timers.set(key,j.duration||0); this.apply(j); return true; },
  tick(dt){ for(const [k,v] of this.cooldowns){ const nv=Math.max(0,v-dt); this.cooldowns.set(k,nv); } for(const [k,v] of this.timers){ const nv=Math.max(0,v-dt); this.timers.set(k,nv); if(nv===0) this.timers.delete(k); } },
  active(id){ return (this.timers.get(id)||0)>0; },
  cdLeft(id){ return this.cooldowns.get(id)||0; },
  apply(j){ switch(j.id){ case 'windStep': doDash(); player.maxSpeed = 260*1.10; setTimeout(()=>player.maxSpeed=260, (j.duration*1000)|0); break; case 'substitution': player.subArmed=true; player.subTimer=j.duration; break; case 'chakraGuard': AssetKit.sfx.guard(); break; case 'timeSlip': game.slowFactor=0.5; setTimeout(()=>game.slowFactor=1, (j.duration*1000)|0); break; case 'cloneDecoy': spawnClone(); break; case 'paperSealBurst': radialPulse(); break; } }
};

function spawnClone(){ const obj={type:PTYPE.CLONE,x:player.x,y:player.y-10,w:18,h:24,hp:20,ttl:4}; clones.push(obj); }
function radialPulse(){ AssetKit.sfx.explode(); const R=120; const px=player.x, py=player.y-12; for(const p of projectiles){ if(!p.active) continue; const dx=p.x-px, dy=p.y-py; const d=Math.hypot(dx,dy); if(d<R){ const k=(R-d)/R; p.vx=(dx/d||0)*220*k; p.vy=(dy/d||0)*-180*k; if(p.type===PTYPE.PAPER){ p.fuse=0.25; p.armed=true; p.reduced=true; } } } }

function doDash(){ if(player.dashCD>0) return; player.dashActive=true; player.dashI = 0.2 + (player.armor.dashIframeBonus||0); player.iTimer = Math.max(player.iTimer, player.dashI); player.dashCD=0.6; player.vx += (Input.left?-1:Input.right?1:(player.vx>=0?1:-1)) * player.dashSpeed; AssetKit.sfx.dash(); }

function AABB(a,b){ return Math.abs(a.x-b.x) < (a.w+b.w)*0.5 && Math.abs((a.y-a.h*0.5)-(b.y-b.h*0.5)) < (a.h+b.h)*0.5; }
function circleHit(x,y,px,py,r){ const dx=x-px, dy=y-py; return dx*dx+dy*dy <= r*r; }

function damage(d){
  if(player.iTimer>0) return false;
  if(JutsuSystem.active('chakraGuard')){ return false; }
  if(player.subArmed){ player.subArmed=false; player.subTimer=0; AssetKit.sfx.dash(); const log={x:player.x-24,y:player.y-8,w:12,h:24,ttl:0.6}; spawn({type:PTYPE.AOE, ...log}); for(const p of projectiles){ if(!p.active) continue; const dx=p.x-log.x, dy=p.y-log.y; const dd=Math.hypot(dx,dy); if(dd<90){ p.vx=(dx/dd||0)*-140; p.vy=(dy/dd||0)*-120; } } return false; }
  const red = 1 - (player.armor.damageReduction||0); const dmg = Math.ceil(d*red); player.hp=Math.max(0, player.hp - dmg); player.iTimer=0.35; player.invFlash=0.15; AssetKit.sfx.hit(); if(saveState.options.shake) shakeTimer=0.15; return true;
}

let last=now(); let shakeTimer=0, shakeAmt=0;
function update(){ const t=now(); let dt=(t-last)/1000; last=t; dt=Math.min(0.033, dt); if(game.state===State.PLAY && !game.paused){ step(dt); } draw(); requestAnimationFrame(update); }

function step(dt){
  if(player.dashCD>0) player.dashCD-=dt; if(player.iTimer>0) player.iTimer-=dt; if(player.invFlash>0) player.invFlash-=dt; if(player.subTimer>0){player.subTimer-=dt; if(player.subTimer<=0) player.subArmed=false;}
  const extraRegen = (player.armor.chakraRegen||0)*20; player.chakra = clamp(player.chakra + (player.chakraRegen + extraRegen)*dt, 0, player.maxChakra);
  const accel = 980; const drag = 8; player.ax = (Input.left?-1:0) + (Input.right?1:0); player.vx += player.ax*accel*dt; const maxV = player.maxSpeed * (1 + (player.armor.speedMod||0)); player.vx = clamp(player.vx, -maxV, maxV); if(player.ax===0) player.vx *= (1 - Math.min(drag*dt,1)); player.x += player.vx*dt; player.x = clamp(player.x, 16, WORLD.w-16);
  if(Input.dash){ doDash(); Input.dash=false; } if(player.dashActive){ player.dashActive=false; }
  if(Input.j1){ if(JutsuSystem.use(player.j1)) stylePopup("J1: "+(player.j1?.name||'')); Input.j1=false; }
  if(Input.j2){ if(JutsuSystem.use(player.j2)) stylePopup("J2: "+(player.j2?.name||'')); Input.j2=false; }
  if(Input.sub){ if(player.j1?.id==='substitution' || player.j2?.id==='substitution'){ JutsuSystem.use({ ...DATA.jutsu.find(j=>j.id==='substitution') }); } Input.sub=false; }
  if(Input.pause){ togglePause(); Input.pause=false; }
  const pdt = dt * (game.slowFactor||1); game.time += dt; waveController(pdt);
  for(const p of projectiles){ if(!p.active) continue; switch(p.type){ case PTYPE.KUNAI: p.y+=p.vy*pdt; p.x+=(p.vx||0)*pdt; break; case PTYPE.SHURIKEN: p.y+=p.vy*pdt; p.x+=p.vx*pdt; p.rot=(p.rot||0)+6*pdt; break; case PTYPE.HEAVY: p.y+=p.vy*pdt; break; case PTYPE.PAPER: if(!p.stuck){ p.y+=p.vy*pdt; if(p.y>=WORLD.ground-12){ p.y=WORLD.ground-12; p.stuck=true; p.armed=true; p.timer=(p.fuse||1.2); } } if(p.armed){ p.timer-=dt; if(p.timer<=0){ spawnExplosion(p.x,p.y, p.reduced?70:110, p.reduced?16:28); p.active=false; AssetKit.sfx.explode(); if(saveState.options.shake) shakeTimer=0.18; } } break; case PTYPE.ELITE: const target = clones[0]?.x ?? player.x; const dx = target - p.x; p.vx = (p.vx||0) + Math.sign(dx)*(p.curve||0.8)*40*pdt; p.y+=p.vy*pdt; p.x+=p.vx*pdt; break; case PTYPE.AOE: p.ttl-=dt; if(p.ttl<=0) p.active=false; break; } if(p.y>WORLD.h+60 || p.x<-80 || p.x>WORLD.w+80) { p.active=false; pool.push(p); } }
  for(const c of clones){ c.ttl-=dt; if(c.ttl<=0) c.dead=true; }
  clones = clones.filter(c=>!c.dead);
  for(const p of projectiles){ if(!p.active) continue; if(p.type===PTYPE.AOE||p.type===PTYPE.PAPER&&p.stuck) continue; const dx = Math.abs(p.x-player.x); const dy = Math.abs(p.y-player.y); if(dy<30 && dx<26 && player.iTimer<=0){ if(JutsuSystem.active('chakraGuard')){ if(p.y < player.y-8){ p.vy*=-0.6; p.y-=12; p.vx*=0.4; stylePopup('Deflect'); continue; } } if(AABB({x:player.x,y:player.y,w:player.w,h:player.h},{x:p.x,y:p.y,w:p.w||10,h:p.h||10})){ if(p.type===PTYPE.HEAVY && saveState.options.shake) shakeTimer=0.25; const took=damage(p.dmg||12); if(took) p.active=false; continue; } }
    if(dy<18 && Math.abs(dx-26)<2){ player.style++; floatingTexts.push({x:player.x,y:player.y-28,t:'+Style',ttl:0.6}); }
    for(const c of clones){ if(AABB({x:c.x,y:c.y,w:c.w,h:c.h},{x:p.x,y:p.y,w:p.w||10,h:p.h||10})){ c.hp-=10; p.active=false; if(c.hp<=0) c.dead=true; break; } }
  }
  if(player.hp<=0){ endRun(); }
  JutsuSystem.tick(dt);
  if(shakeTimer>0){ shakeTimer-=dt; shakeAmt = lerp(shakeAmt, 6, 0.2); } else { shakeAmt = lerp(shakeAmt, 0, 0.2); }
}

const effects=[]; const floatingTexts=[];
function spawnExplosion(x,y,r,dmg){ if(circleHit(x,y,player.x,player.y-6,r) && player.iTimer<=0) damage(dmg); effects.push({x,y,r,ttl:0.35}); }
function stylePopup(t){ floatingTexts.push({x:player.x,y:player.y-30,t,ttl:0.8}); }

function draw(){ ctx.save(); ctx.fillStyle = '#0c111a'; ctx.fillRect(0, WORLD.ground, WORLD.w, WORLD.h-WORLD.ground); drawBackground(); if(shakeAmt>0) ctx.translate((Math.random()-0.5)*shakeAmt, (Math.random()-0.5)*shakeAmt); ctx.fillStyle=COLORS.dome; ctx.beginPath(); ctx.ellipse(WORLD.w/2,WORLD.ground-20, WORLD.w*0.46, WORLD.h*0.65, 0, 0, Math.PI, true); ctx.fill(); if(game.state===State.PLAY || game.state===State.PAUSE){ drawPlay(); } ctx.restore(); }

function drawBackground(){ ctx.fillStyle = '#121826'; for(let i=0;i<6;i++){ const x=80+i*140; ctx.fillRect(x, WORLD.ground-48, 16, 48); } const grd=ctx.createLinearGradient(0,WORLD.ground-60,0,WORLD.ground); grd.addColorStop(0,'rgba(245,133,30,0.08)'); grd.addColorStop(1,'rgba(245,133,30,0.0)'); ctx.fillStyle=grd; ctx.fillRect(0,WORLD.ground-60,WORLD.w,60); }

function drawPlay(){ drawPlayer(); for(const p of projectiles){ if(!p.active) continue; drawProjectile(p); } for(const e of effects){ e.ttl-=0.016; const a=clamp(e.ttl/0.35,0,1); ctx.fillStyle=`rgba(245,133,30,${0.35*a})`; ctx.beginPath(); ctx.arc(e.x,e.y, e.r*(1.1-a*0.4), 0, Math.PI*2); ctx.fill(); } for(const f of floatingTexts){ f.ttl-=0.016; f.y-=20*0.016; ctx.globalAlpha=Math.max(0,f.ttl/0.8); ctx.fillStyle='#cfe3ff'; ctx.font='14px system-ui'; ctx.textAlign='center'; ctx.fillText(f.t, f.x, f.y); ctx.globalAlpha=1; } drawHUD(); if(game.paused){ drawPause(); } }

function drawPlayer(){ ctx.save(); ctx.translate(player.x, player.y); ctx.fillStyle='rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(0,6,14,5,0,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#eab308'; ctx.fillRect(-10,-26,20,24); ctx.fillStyle='#cbd5e1'; ctx.fillRect(-8,-40,16,14); ctx.fillStyle='#b45309'; ctx.fillRect(-10,-16,20,4); if(player.iTimer>0 && Math.sin(performance.now()/50)>0) { ctx.globalCompositeOperation='lighter'; ctx.fillStyle='rgba(255,255,255,0.35)'; ctx.fillRect(-12,-42,24,42); ctx.globalCompositeOperation='source-over'; } ctx.restore(); if(player.subArmed){ ctx.strokeStyle='#94a3b8'; ctx.strokeRect(player.x-14, player.y-44, 28, 44); } for(const c of clones){ ctx.fillStyle='rgba(148,163,184,0.5)'; ctx.fillRect(c.x-9,c.y-22,18,24); }
}

function drawProjectile(p){ const outline = saveState.options.outline; switch(p.type){ case PTYPE.KUNAI: ctx.fillStyle='#8aa0b6'; if(outline){ctx.strokeStyle='#fff';ctx.strokeRect(p.x-3,p.y-9,6,18);} ctx.fillRect(p.x-3,p.y-9,6,18); break; case PTYPE.SHURIKEN: ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(p.rot||0); ctx.fillStyle='#94a3b8'; if(outline){ctx.strokeStyle='#fff'; ctx.strokeRect(-7,-7,14,14);} ctx.fillRect(-7,-2,14,4); ctx.fillRect(-2,-7,4,14); ctx.restore(); break; case PTYPE.HEAVY: ctx.fillStyle='rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(p.x,(p.shadowY||WORLD.ground-8), 18, 6, 0,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#7f5539'; ctx.fillRect(p.x-12,p.y-12,24,24); if(outline){ctx.strokeStyle='#fff'; ctx.strokeRect(p.x-12,p.y-12,24,24);} break; case PTYPE.PAPER: ctx.fillStyle='#ef4444'; ctx.fillRect(p.x-4,p.y-9,8,18); if(p.stuck){ ctx.fillStyle='rgba(255,255,255,0.25)'; ctx.fillRect(p.x-6,p.y+10,12,4); } break; case PTYPE.ELITE: ctx.fillStyle=p.color||'#ff6b6b'; ctx.fillRect(p.x-3,p.y-9,6,18); if(outline){ctx.strokeStyle='#fff'; ctx.strokeRect(p.x-3,p.y-9,6,18);} break; case PTYPE.AOE: ctx.fillStyle='rgba(148,163,184,0.6)'; ctx.fillRect(p.x-p.w*0.5,p.y-p.h, p.w, p.h); break; } }

function drawHUD(){ const pad=10; const bw=220; const hpw = bw*(player.hp/player.maxHp); ctx.fillStyle='#0b0f1a'; ctx.fillRect(pad, pad, bw, 12); ctx.fillStyle=COLORS.hp; ctx.fillRect(pad, pad, hpw, 12); ctx.strokeStyle='#2b3347'; ctx.strokeRect(pad, pad, bw, 12); ctx.fillStyle='#cfe3ff'; ctx.font='12px system-ui'; ctx.fillText('HP', pad+4, pad+10); const chw = bw*(player.chakra/player.maxChakra); ctx.fillStyle='#0b0f1a'; ctx.fillRect(pad, pad+18, bw, 12); ctx.fillStyle=COLORS.chakra; ctx.fillRect(pad, pad+18, chw, 12); ctx.strokeStyle='#2b3347'; ctx.strokeRect(pad, pad+18, bw, 12); ctx.fillStyle='#cfe3ff'; ctx.fillText('Chakra', pad+4, pad+28); ctx.textAlign='right'; ctx.fillText(`Time ${game.time.toFixed(1)}s  Style ${player.style}`,  WORLD.w-10, 18); ctx.textAlign='left'; const slots=[player.j1, player.j2]; for(let i=0;i<2;i++){ const j=slots[i]; const x=pad+i*(bw*0.5+12); const y=pad+36; ctx.strokeStyle='#2b3347'; ctx.strokeRect(x,y, bw*0.5, 12); if(j){ const cd=JutsuSystem.cdLeft(j.id); const r=cd>0? (1-cd/j.cooldown):1; ctx.fillStyle= cd>0? '#374151':'#16a34a'; ctx.fillRect(x,y, (bw*0.5)*r, 12); ctx.fillStyle='#cfe3ff'; ctx.fillText(j.name, x+4, y+10); } else { ctx.fillStyle='#475569'; ctx.fillRect(x,y, (bw*0.5), 12); ctx.fillStyle='#94a3b8'; ctx.fillText('Empty', x+4, y+10); } }
  ctx.fillStyle='#94a3b8'; ctx.fillText('Esc = Pause', WORLD.w-90, WORLD.h-10);
}

function drawPause(){ ctx.save(); ctx.globalAlpha=0.8; ctx.fillStyle='#0b0f1a'; ctx.fillRect(WORLD.w/2-120, WORLD.h/2-50, 240, 100); ctx.globalAlpha=1; ctx.strokeStyle='#2b3347'; ctx.strokeRect(WORLD.w/2-120, WORLD.h/2-50, 240, 100); ctx.fillStyle='#cfe3ff'; ctx.font='18px system-ui'; ctx.textAlign='center'; ctx.fillText('Paused', WORLD.w/2, WORLD.h/2-10); ctx.font='12px system-ui'; ctx.fillText('Press Esc to resume', WORLD.w/2, WORLD.h/2+16); ctx.textAlign='left'; ctx.restore(); }

function startRun(){ player.hp=100; player.chakra=100; player.style=0; player.iTimer=0; player.vx=0; game.time=0; game.tierTime=0; game.volleyTime=0; game.slowFactor=1; spawner.tier=0; spawner.time=0; spawner.next=0; resetProjectiles(); clones.length=0; JutsuSystem.cooldowns.clear(); JutsuSystem.timers.clear(); game.state=State.PLAY; game.paused=false; showPanel(null); }
function endRun(){ game.state=State.GAMEOVER; game.paused=true; const base = Math.floor(game.time); const style = Math.floor(player.style*0.5); const tpGain = Math.max(1, base + style); saveState.tp += tpGain; saveState.best = Math.max(saveState.best||0, game.time); save(saveState); showPanel('menu'); document.getElementById('progress').style.width = `${Math.min(100, (game.time/60)*100)}%`; document.getElementById('tip').textContent = `Time ${game.time.toFixed(1)}s • Style ${player.style} • TP +${tpGain}`; AssetKit.sfx.ui(); }
function togglePause(){ if(game.state!==State.PLAY) return; game.paused=!game.paused; AssetKit.sfx.ui(); }

// UI wiring
const $ = sel=>document.querySelector(sel);
function showPanel(id){ for(const p of document.querySelectorAll('.panel')) p.classList.remove('show'); if(id) $('#'+id).classList.add('show'); }
function updateMenu(){ const tip = DATA.tips[(Math.floor(Date.now()/1000))%DATA.tips.length]; $('#tip').textContent=tip; $('#seedView').textContent = saveState.options.seed.replace(/^./,c=>c.toUpperCase()); }
function fillChangelog(){ const host=$('#log'); host.innerHTML=''; for(const e of DATA.changelog){ const div=document.createElement('div'); div.style.margin='8px 0'; div.innerHTML=`<b>${e.v}</b> <span class="muted small">(${e.date})</span><ul>${e.notes.map(n=>`<li>${n}</li>`).join('')}</ul>`; host.appendChild(div);} }
function renderLoadout(){ $('#tpView').textContent = saveState.tp|0; $('#bestView').textContent = (saveState.best||0).toFixed(1)+"s"; const jhost=$('#jutsuList'); jhost.innerHTML=''; DATA.jutsu.forEach(j=>{ const unlocked = saveState.unlocked.jutsu[j.id]||j.id==='windStep'; const eq1 = saveState.loadout.j1===j.id; const eq2 = saveState.loadout.j2===j.id; const btn=document.createElement('button'); btn.textContent = `${j.name} (${j.type})`; btn.className = (unlocked?'' : 'locked') + ' tip'; btn.dataset.tip = unlocked ? `${j.chakraCost} chakra • CD ${j.cooldown}s • ${j.effects.join(', ')}` : `Cost ${j.unlocks?.tp||'?'} TP${j.unlocks?.req? ' • Req: '+j.unlocks.req : ''}`; if(unlocked){ btn.addEventListener('click',()=>{ if(!saveState.loadout.j1){ saveState.loadout.j1=j.id; } else if(saveState.loadout.j1!==j.id && !saveState.loadout.j2){ saveState.loadout.j2=j.id; } else if(saveState.loadout.j1===j.id){ saveState.loadout.j1=null; } else if(saveState.loadout.j2===j.id){ saveState.loadout.j2=null; } else { saveState.loadout.j1=j.id; } equipFromSave(); save(saveState); renderLoadout(); }); } else { btn.addEventListener('click',()=>{ const cost=j.unlocks?.tp||9999; if(saveState.tp>=cost){ saveState.tp-=cost; saveState.unlocked.jutsu[j.id]=true; save(saveState); renderLoadout(); } else { AssetKit.sfx.ui(); } }); }
      jhost.appendChild(btn); if(eq1||eq2){ const tag=document.createElement('span'); tag.className='small muted'; tag.textContent= eq1? ' • Slot J1' : ' • Slot J2'; jhost.appendChild(tag);} });
  const ahost=$('#armorList'); ahost.innerHTML=''; DATA.armor.forEach(a=>{ const unlocked = saveState.unlocked.armor[a.id]||!!a.default; const btn=document.createElement('button'); btn.textContent = `${a.name}`; btn.className=(unlocked?'' : 'locked')+ ' tip'; btn.dataset.tip = unlocked? `${Math.round(a.damageReduction*100)}% DR • Speed ${Math.round(a.speedMod*100)}%` : `Cost ${a.tp} TP`; if(unlocked){ btn.addEventListener('click',()=>{ saveState.loadout.armor=a.id; equipFromSave(); save(saveState); renderLoadout(); }); } else { btn.addEventListener('click',()=>{ if(saveState.tp>=a.tp){ saveState.tp-=a.tp; saveState.unlocked.armor[a.id]=true; save(saveState); renderLoadout(); } else AssetKit.sfx.ui(); }); } ahost.appendChild(btn); if(saveState.loadout.armor===a.id){ const tag=document.createElement('span'); tag.className='small muted'; tag.textContent=' • Equipped'; ahost.appendChild(tag); } }); }
function renderOptions(){ $('#optMusic').value=saveState.options.music; $('#optSfx').value=saveState.options.sfx; $('#optShake').checked=!!saveState.options.shake; $('#optOutline').checked=!!saveState.options.outline; $('#optSeed').value=saveState.options.seed; $('#optHaptics').checked=!!saveState.options.haptics; }
function bindOptions(){ $('#optMusic').addEventListener('input',e=>{saveState.options.music=parseFloat(e.target.value); save(saveState);}); $('#optSfx').addEventListener('input',e=>{saveState.options.sfx=parseFloat(e.target.value); save(saveState);}); $('#optShake').addEventListener('change',e=>{saveState.options.shake=e.target.checked; save(saveState);}); $('#optOutline').addEventListener('change',e=>{saveState.options.outline=e.target.checked; save(saveState);}); $('#optSeed').addEventListener('change',e=>{saveState.options.seed=e.target.value; setSeed(e.target.value); save(saveState);}); $('#optHaptics').addEventListener('change',e=>{saveState.options.haptics=e.target.checked; save(saveState);}); }

// Buttons
$('#btnPlay').addEventListener('click',()=>{ equipFromSave(); startRun(); });
$('#btnPlayFromLoadout').addEventListener('click',()=>{ equipFromSave(); startRun(); });
$('#btnLoadout').addEventListener('click',()=>{ renderLoadout(); showPanel('loadout'); });
$('#btnOptions').addEventListener('click',()=>{ renderOptions(); showPanel('options'); });
$('#btnBack1').addEventListener('click',()=>{ showPanel('menu'); updateMenu(); });
$('#btnBack2').addEventListener('click',()=>{ showPanel('menu'); updateMenu(); });
$('#btnChangelog').addEventListener('click',()=>{ fillChangelog(); showPanel('changelog'); });
$('#btnBack3').addEventListener('click',()=>{ showPanel('menu'); updateMenu(); });
$('#btnCredits').addEventListener('click',()=>{ showPanel('credits'); });
$('#btnBack4').addEventListener('click',()=>{ showPanel('menu'); updateMenu(); });
$('#btnSandbox').addEventListener('click',()=>{ equipFromSave(); startRun(); });
$('#btnDrills').addEventListener('click',()=>{ document.getElementById('coming').classList.add('show'); });
$('#btnCloseComing').addEventListener('click',()=>{ document.getElementById('coming').classList.remove('show'); });

// Init
updateMenu(); renderOptions(); bindOptions(); requestAnimationFrame(update);
