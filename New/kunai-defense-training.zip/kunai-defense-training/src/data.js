// Game Data (JSON)
export const DATA = {
  jutsu: [
    { id:"windStep", name:"Wind Step", type:"mobility", chakraCost:15, cooldown:5, duration:3, effects:["dash","speedBuff"], unlocks:{ tp:50, req:"Survive 45s" } },
    { id:"substitution", name:"Substitution", type:"defense", chakraCost:25, cooldown:12, duration:4, effects:["negateNextHit","decoyKnockback"], unlocks:{ tp:80 } },
    { id:"chakraGuard", name:"Chakra Guard", type:"shield", chakraCost:20, cooldown:10, duration:2, effects:["frontalDeflect"], unlocks:{ tp:75 } },
    { id:"timeSlip", name:"Time Slip", type:"control", chakraCost:40, cooldown:18, duration:2.5, effects:["globalSlowProjectiles"], unlocks:{ tp:120, req:"Survive 60s" } },
    { id:"cloneDecoy", name:"Clone Decoy", type:"control", chakraCost:25, cooldown:14, duration:4, effects:["aggroAttractor"], unlocks:{ tp:90 } },
    { id:"paperSealBurst", name:"Paper Seal Burst", type:"utility", chakraCost:22, cooldown:12, duration:0.1, effects:["radialKnockback","earlyDetonate"], unlocks:{ tp:95 } }
  ],
  armor: [
    { id:"cloth", name:"Cloth", damageReduction:0, speedMod:0.05, tp:0, default:true },
    { id:"padded", name:"Padded Vest", damageReduction:0.15, speedMod:-0.05, tp:60 },
    { id:"reinforced", name:"Reinforced Vest", damageReduction:0.25, speedMod:-0.10, tp:120, dashIframeBonus:0.5 },
    { id:"chakraWoven", name:"Chakra-woven", damageReduction:0.30, speedMod:-0.05, tp:200, chakraRegen:0.05 }
  ],
  changelog: [
    { v:"0.1.0", date:"2025-08-27", notes:[
      "Endless mode core loop",
      "6 jutsu, 4 armor tiers",
      "Spawner with rows/sine/aimed/random/meteor/elite curve",
      "Near-miss scoring + style bonuses",
      "Desktop + mobile inputs",
      "Local save: TP, unlocks, options, loadout",
      "Options: volume, shake, outline, seed",
      "Menus: Main, Loadout, Options, Changelog, Credits"
    ]}
  ],
  tips:[
    "Heavies cast a long shadow before impact.",
    "Dash through gaps; don’t outrun the wave.",
    "Substitution nullifies one hit—arm it early.",
    "Red-hued elites curve; bait them to one side.",
    "Guard deflects forward—face the danger.",
    "Near-misses grant style TP; play brave, not dumb."
  ]
};
