export const SAVE_KEY = "kdt_save_v010";
export const defaults = {
  tp: 0,
  best: 0,
  unlocked: { jutsu: {windStep:true}, armor: {cloth:true} },
  loadout: { j1:"windStep", j2:null, armor:"cloth" },
  options: { music:0.0, sfx:0.6, shake:true, outline:false, seed:"normal", haptics:false }
};
export function loadSave(){
  try{
    const raw = JSON.parse(localStorage.getItem(SAVE_KEY)||"{}");
    return Object.assign({}, defaults, raw);
  }catch(e){ return JSON.parse(JSON.stringify(defaults)); }
}
export function save(state){ localStorage.setItem(SAVE_KEY, JSON.stringify(state)); }
