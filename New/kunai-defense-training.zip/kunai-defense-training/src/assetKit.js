// Minimal Asset Kit: placeholder SFX via WebAudio
export function makeAssetKit(getOptions){
  const ctx = new (window.AudioContext||window.webkitAudioContext)();
  function beep(freq=440, dur=0.08, type="sine", gain=0.15){
    const { sfx=0.6 } = getOptions();
    if (sfx<=0) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type; o.frequency.value = freq; o.connect(g); g.connect(ctx.destination);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain*sfx, t+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    o.start(t); o.stop(t+dur);
  }
  const sfx = {
    hit: ()=>beep(160,0.12,"square",0.22),
    dash: ()=>beep(720,0.07,"sine",0.12),
    guard:()=>beep(520,0.10,"sawtooth",0.10),
    explode:()=>beep(80,0.15,"triangle",0.25),
    gong:()=>{beep(440,0.15,"sine",0.2); setTimeout(()=>beep(220,0.4,"sine",0.18),60);},
    ui: ()=>beep(880,0.05,"sine",0.08)
  };
  return { sfx };
}
