export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const randRange=(a,b)=>a+Math.random()*(b-a);
export const now=()=>performance.now();
