# Assets (placeholders)

This MVP uses only canvas shapes and WebAudio beeps.

Drop real sprites/audio here later:
- `sprites/` (PNG/WebP)
- `audio/` (WAV/OGG/MP3)

Then replace draw calls in `src/main.js` and SFX in `src/assetKit.js`.
