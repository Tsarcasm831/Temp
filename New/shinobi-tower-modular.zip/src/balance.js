import { META } from './state.js';
import { CONFIG } from './constants.js';

export function appliedStats(){
  const u = META.upgrades;
  const assist = META.options.assist?1:0;
  return {
    maxHP: Math.round(CONFIG.base.hp * (1 + 0.12*u.armor.lvl) + assist*20),
    dmg: CONFIG.base.dmg * (1 + 0.10*u.dmg.lvl),
    firerate: CONFIG.base.firerate * (1 + 0.08*u.firerate.lvl),
    range: CONFIG.base.range * (1 + 0.07*u.range.lvl),
    projspd: CONFIG.base.projspd * (1 + 0.10*u.projspd.lvl),
    regen: CONFIG.base.regen + 0.3*u.regen.lvl + assist*0.15,
    multishot: 1 + Math.floor(u.multishot.lvl/3),
    splitChance: Math.max(0, Math.min(0.10*u.splitshot.lvl, 0.6)),
  };
}
