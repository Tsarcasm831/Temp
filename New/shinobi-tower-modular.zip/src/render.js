import { ctx, CX, CY } from './engine.js';
import { World } from './world.js';
import { clamp, lerp, rand, roundedRect } from './utils.js';
import { CONFIG } from './constants.js';

function drawKunai(x,y,ang,blade='#d7e0e8'){
  ctx.save(); ctx.translate(x,y); ctx.rotate(ang);
  const grad = ctx.createLinearGradient(0,0,18,0); grad.addColorStop(0,'#eef5ff'); grad.addColorStop(1,blade);
  ctx.fillStyle=grad; ctx.beginPath(); ctx.moveTo(18,0); ctx.lineTo(-8,-7); ctx.lineTo(-8,7); ctx.closePath(); ctx.fill();
  ctx.fillStyle='#2b333d'; ctx.fillRect(-9,-5,3,10);
  ctx.fillStyle='#3a444f'; ctx.fillRect(-14,-3,5,6);
  ctx.beginPath(); ctx.arc(-16,0,3,0,Math.PI*2); ctx.lineWidth=2; ctx.strokeStyle='#2b333d'; ctx.stroke();
  ctx.restore();
}
function drawShuriken(x,y,ang){
  ctx.save(); ctx.translate(x,y); ctx.rotate(ang + Math.PI/4);
  ctx.fillStyle = '#9fe8ff';
  for(let i=0;i<4;i++){ ctx.rotate(Math.PI/2); ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(8,-2); ctx.lineTo(2,-8); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = '#11222c'; ctx.beginPath(); ctx.arc(0,0,1.8,0,Math.PI*2); ctx.fill(); ctx.restore();
}
function drawTower(){
  ctx.save(); ctx.translate(CX, CY);
  ctx.fillStyle = '#1f2d3a'; roundedRect(ctx,-20,-56,40,112,12); ctx.fill();
  ctx.fillStyle = '#253241'; ctx.fillRect(-22,-12,44,6); ctx.fillRect(-22,8,44,6);
  ctx.beginPath(); ctx.moveTo(0,-70); ctx.lineTo(16,-36); ctx.lineTo(-16,-36); ctx.closePath();
  const g = ctx.createLinearGradient(0,-70,0,-36); g.addColorStop(0,'#4cd9ff'); g.addColorStop(1,'#0c6abf'); ctx.fillStyle=g; ctx.fill();
  const ga = ctx.createRadialGradient(0,-54,2, 0,-54,24); ga.addColorStop(0,'rgba(45,212,255,.6)'); ga.addColorStop(1,'rgba(45,212,255,0)');
  ctx.fillStyle=ga; ctx.beginPath(); ctx.arc(0,-54,24,0,Math.PI*2); ctx.fill(); ctx.restore();
}
function drawBarrierRing(Game){
  const ringR = Math.min(innerWidth, innerHeight)*0.42;
  const hpFrac = clamp(Game.hp/Game.hpMax, 0, 1);
  ctx.save();
  ctx.strokeStyle = '#0f141a'; ctx.lineWidth=1; ctx.globalAlpha=0.5;
  for(let x=CX-ringR; x<=CX+ringR; x+=32){ ctx.beginPath(); ctx.moveTo(x, CY-ringR); ctx.lineTo(x, CY+ringR); ctx.stroke(); }
  for(let y=CY-ringR; y<=CY+ringR; y+=32){ ctx.beginPath(); ctx.moveTo(CX-ringR, y); ctx.lineTo(CX+ringR, y); ctx.stroke(); }
  ctx.globalAlpha=1;
  ctx.beginPath(); ctx.arc(CX, CY, ringR, 0, Math.PI*2);
  ctx.strokeStyle = '#233043'; ctx.lineWidth = 2; ctx.globalAlpha=0.7; ctx.stroke(); ctx.globalAlpha=1;
  const start = -Math.PI/2; const end = start + hpFrac*2*Math.PI;
  const gg = ctx.createLinearGradient(CX-ringR, CY, CX+ringR, CY); gg.addColorStop(0,'#21c7ff'); gg.addColorStop(1, hpFrac>0.33? '#0ea5e9' : '#ff6b6b');
  ctx.strokeStyle = gg; ctx.lineWidth=6; ctx.beginPath(); ctx.arc(CX,CY, ringR+6, start, end); ctx.stroke();
  ctx.restore();
}
function drawLeaves(World, dt){
  for(const l of World.leaves){
    l.x += Math.cos(l.a)*l.s*dt*0.15; l.y += Math.sin(l.a*0.6)*l.s*dt*0.15;
    if(l.x<-20) l.x=innerWidth+20; if(l.x>innerWidth+20) l.x=-20;
    if(l.y<-20) l.y=innerHeight+20; if(l.y>innerHeight+20) l.y=-20;
    ctx.fillStyle='#1a4426'; ctx.beginPath(); ctx.ellipse(l.x,l.y, l.r, l.r*0.6, l.a,0,Math.PI*2); ctx.fill();
  }
}

export function render(Game, dt){
  ctx.clearRect(0,0,innerWidth,innerHeight);
  if(Game.shake>0){ const sx=rand(-Game.shake,Game.shake), sy=rand(-Game.shake,Game.shake); ctx.save(); ctx.translate(sx,sy); Game.shake = Math.max(0, Game.shake - 60*dt); }
  drawLeaves(World, dt);
  drawBarrierRing(Game);
  drawTower();
  for(const e of World.enemies){
    const a = Math.atan2(CY-e.y, CX-e.x); drawKunai(e.x,e.y,a);
    const m = Math.max(0, Math.min(1, e.hp / (CONFIG.enemy.baseHP * Math.pow(CONFIG.enemy.hpGrowth, Math.max(0,Game.wave-1)))));
    ctx.fillStyle = '#0e1319'; ctx.fillRect(e.x-12, e.y-18, 24, 4);
    ctx.fillStyle = '#35d07f'; ctx.fillRect(e.x-12, e.y-18, 24*m, 4);
  }
  for(const p of World.shots){ drawShuriken(p.x,p.y,p.a); }
  for(const f of World.effects){
    const t=Math.max(0, Math.min(1, f.life/0.2)); ctx.globalAlpha=t; ctx.fillStyle=f.color;
    ctx.beginPath(); ctx.arc(f.x,f.y, lerp(0,f.r,1-t), 0, Math.PI*2); ctx.fill(); ctx.globalAlpha=1;
  }
  if(Game.shake>0){ ctx.restore(); }
}
