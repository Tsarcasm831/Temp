import { World } from './world.js';
import { rand } from './utils.js';
import { CX, CY } from './engine.js';
import { CONFIG } from './constants.js';
import { META } from './state.js';
import { beep } from './audio.js';

export const Waves = {
  spawning:false, toSpawn:0, spawnTimer:0,
  update(Game, dt){
    if(Game.paused) return;
    if(!this.spawning && World.enemies.length===0 && Game.alive){
      Game.wave++; Game.updateHUD();
      const n = 6 + Math.floor(Game.wave*1.5);
      this.startWave(n);
      Game.ryoRun += CONFIG.ryo.wave;
      beep(880,0.06,0.05);
    }
    if(this.spawning){
      this.spawnTimer -= dt;
      if(this.spawnTimer<=0 && this.toSpawn>0){
        this.spawnOne(Game.wave);
        this.toSpawn--;
        this.spawnTimer = 0.18;
        if(this.toSpawn<=0) this.spawning=false;
      }
    }
  },
  startWave(n){ this.spawning=true; this.toSpawn=n; this.spawnTimer=0.2; },
  spawnOne(wave){
    const ang = rand(0,Math.PI*2);
    const r = Math.min(innerWidth, innerHeight)*0.42;
    const x = CX + Math.cos(ang)*r;
    const y = CY + Math.sin(ang)*r;
    const hp = CONFIG.enemy.baseHP * Math.pow(CONFIG.enemy.hpGrowth, Math.max(0,wave-1));
    let spd = CONFIG.enemy.baseSpeed * Math.pow(CONFIG.enemy.spdGrowth, Math.max(0,wave-1));
    if(META.options.assist) spd *= 0.9;
    World.enemies.push({x, y, hp, spd, alive:true, r:10, dps:7});
  }
};
