export class Enemy { constructor(x,y,hp,spd){ this.x=x; this.y=y; this.hp=hp; this.spd=spd; this.alive=true; this.r=10; this.dps=7; } }
export class Shot  { constructor(x,y,vx,vy,damage,life){ this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.damage=damage; this.life=life; this.r=4; this.a=Math.atan2(vy,vx);} }

export const World = {
  enemies: [],
  shots: [],
  effects: [],
  leaves: [],
  clear(){ this.enemies.length=0; this.shots.length=0; this.effects.length=0; }
};
