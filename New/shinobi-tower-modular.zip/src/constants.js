export const SAVE_KEY = 'shinobi-tower-canvas-meta-v2';
export const META_DEFAULT = {
  ryo: 0,
  options: { assist:false, muted:false },
  upgrades: {
    dmg: {lvl:0},
    firerate:{lvl:0},
    range:{lvl:0},
    projspd:{lvl:0},
    armor:{lvl:0},
    regen:{lvl:0},
    multishot:{lvl:0},
    splitshot:{lvl:0},
  }
};

export const CONFIG = {
  base: {
    hp: 180,
    dmg: 10,
    firerate: 1.2,
    range: 260,
    projspd: 560,
    regen: 0.0,
    multishot: 1,
    splitChance: 0.0,
  },
  enemy: {
    baseHP: 38,
    baseSpeed: 64,
    hpGrowth: 1.18,
    spdGrowth: 1.06,
    ringRadius: 380,
  },
  ryo: { kill: 3, wave: 25, bankFactor: 1.0 },
  modes: { ENDLESS:'endless', TIMED:'timed' }
};
