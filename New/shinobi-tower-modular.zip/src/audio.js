import { META } from './state.js';

let AC = null;
export function ensureAudio(){ if(!AC){ AC = new (window.AudioContext||window.webkitAudioContext)(); } }
export function tone(freq=660, dur=0.05, vol=0.03, type='triangle'){
  if(!AC || META.options.muted) return;
  const o=AC.createOscillator(), g=AC.createGain();
  o.type=type; o.frequency.value=freq; g.gain.value=vol;
  o.connect(g).connect(AC.destination); o.start(); o.stop(AC.currentTime+dur);
}
export const beep = (...a)=>tone(...a);
