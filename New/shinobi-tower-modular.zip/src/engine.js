export const canvas = document.getElementById('game');
export const ctx = canvas.getContext('2d');

export let DPR=1, CX=0, CY=0;

export function resize(){
  DPR = Math.min(2, window.devicePixelRatio||1);
  canvas.width = Math.floor(innerWidth * DPR);
  canvas.height = Math.floor(innerHeight * DPR);
  canvas.style.width = innerWidth + 'px';
  canvas.style.height = innerHeight + 'px';
  ctx.setTransform(1,0,0,1,0,0);
  ctx.scale(DPR,DPR);
  CX = innerWidth/2; CY = innerHeight/2;
}
window.addEventListener('resize', resize);
resize();
