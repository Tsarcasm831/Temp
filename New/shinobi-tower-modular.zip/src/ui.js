import { persist, resetMeta, META } from './state.js';
import { CONFIG } from './constants.js';
import { World } from './world.js';

const $ = s=>document.querySelector(s);
const menu = $('#menu'), shop = $('#shop'), over = $('#over');
const hudWave = $('#ui-wave'), hudHP = $('#ui-hp'), hudHPM = $('#ui-hpmax'), hudRyo = $('#ui-ryo');
const shopGrid = $('#shop-grid'), shopRyo = $('#shop-ryo');
const summary = $('#summary'), bankedEl = $('#banked');
const overTitle = $('#over-title'); const assistLabel = $('#assist-label');

export function hide(el){ el.classList.add('hidden'); }
export function show(el){ el.classList.remove('hidden'); }

export function setAssistUI(){ assistLabel.textContent = META.options.assist? 'ON' : 'OFF'; assistLabel.style.color = META.options.assist? 'var(--good)' : 'var(--text)'; }

export function updateHUD(Game){ hudWave.textContent = Game.wave|0; hudHP.textContent = Math.max(0,Game.hp|0); hudHPM.textContent = Game.hpMax|0; hudRyo.textContent = (META.ryo|0) + (Game.running? (' + '+(Game.ryoRun|0)) : ''); }

export function openShop(){ shopRyo.textContent = META.ryo|0; buildShop(); show(shop); hide(menu); hide(over); }

export function wireUI(Game){
  $('#btn-play').addEventListener('click', ()=>{ Game.start('endless'); hide(menu); });
  $('#btn-play-timed').addEventListener('click', ()=>{ Game.start('timed'); hide(menu); });
  $('#btn-shop').addEventListener('click', ()=>{ openShop(); });
  $('#btn-close-shop').addEventListener('click', ()=>{ hide(shop); show(menu); });
  $('#btn-reset').addEventListener('click', ()=>{ if(confirm('Wipe local save?')){ resetMeta(); buildShop(); updateHUD(Game); setAssistUI(); } });
  $('#toggle-assist').addEventListener('click', ()=>{ META.options.assist=!META.options.assist; persist(); setAssistUI(); });
  $('#btn-over-retry').addEventListener('click', ()=>{ hide(over); Game.start(Game.mode); });
  $('#btn-over-shop').addEventListener('click', ()=>{ hide(over); openShop(); });
  $('#btn-over-menu').addEventListener('click', ()=>{ hide(over); show(menu); });
}

export function buildShop(){
  const defs = upgradeDefs(); shopGrid.innerHTML = '';
  for(const u of defs){
    const lvl = META.upgrades[u.key].lvl|0; const cost = u.cost(lvl);
    const el = document.createElement('div'); el.className='upgrade';
    el.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <strong>${u.name}</strong>
        <span class="note">Lv ${lvl}</span>
      </div>
      <div class="note" style="margin:6px 0 8px">${u.desc}</div>
      <progress max="1" value="${u.progress(lvl)}"></progress>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px">
        <span>Cost: <b style="color:var(--gold)">${cost}</b> Ryo</span>
        <button class="btn" ${META.ryo<cost?'disabled':''}>Buy</button>
      </div>`;
    el.querySelector('button').addEventListener('click', ()=>{
      const lvlNow = META.upgrades[u.key].lvl|0; const c=u.cost(lvlNow);
      if(META.ryo>=c){ META.ryo-=c; META.upgrades[u.key].lvl=lvlNow+1; persist(); buildShop(); }
    });
    shopGrid.appendChild(el);
  }
}

function baseCurve(b){ return (lvl)=>Math.max(5, Math.round(b*Math.pow(1.25,lvl))); }
function tanh01(x){ return (Math.tanh(x*1.25)+1)/2; }

function upgradeDefs(){
  return [
    {key:'dmg', name:'Katon Focus (Damage)', desc:'+10% tower damage per level', cost:baseCurve(40), progress:l=>tanh01(l/50)},
    {key:'firerate', name:'Handseal Speed (Fire Rate)', desc:'+8% fire rate per level', cost:baseCurve(60), progress:l=>tanh01(l/50)},
    {key:'range', name:'Sensory Range', desc:'+7% targeting range per level', cost:baseCurve(50), progress:l=>tanh01(l/50)},
    {key:'projspd', name:'Chakra Bolt Velocity', desc:'+10% projectile speed per level', cost:baseCurve(45), progress:l=>tanh01(l/50)},
    {key:'armor', name:'Chakra Armor (HP)', desc:'+12% max HP per level', cost:baseCurve(70), progress:l=>tanh01(l/50)},
    {key:'regen', name:'Meditation (Regen)', desc:'+0.3 HP/sec per level', cost:baseCurve(55), progress:l=>tanh01(l/50)},
    {key:'multishot', name:'Shadow Clone Arrows', desc:'+1 projectile / 3 levels', cost:baseCurve(80), progress:l=>tanh01(l/30)},
    {key:'splitshot', name:'Shuriken Split', desc:'+10% split chance per level (cap 60%)', cost:baseCurve(65), progress:l=>tanh01(l/6)},
  ];
}

export function showGameOver(Game, reason){
  const banked = Math.round(Game.ryoRun * CONFIG.ryo.bankFactor);
  META.ryo += banked; persist();
  overTitle.textContent = reason||'Training Over';
  summary.innerHTML = `<ul>
      <li>Mode: <b>${Game.mode}</b></li>
      <li>Waves cleared: <b>${Game.wave}</b></li>
      <li>Kills: <b>${Game.kills}</b></li>
      <li>Run Ryo: <b>${Game.ryoRun}</b></li>
      <li>Time survived: <b>${Game.mode==='timed'? (180-Game.timeLeft).toFixed(1)+'s' : Game.t.toFixed(1)+'s'}</b></li>
      <li>Bank factor: <b>${(CONFIG.ryo.bankFactor*100)|0}%</b></li>
    </ul>`;
  bankedEl.textContent = banked;
  show(over);
}
