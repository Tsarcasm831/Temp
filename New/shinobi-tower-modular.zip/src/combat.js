import { World } from './world.js';
import { clamp, rand } from './utils.js';
import { CX, CY } from './engine.js';

export function aimAndShoot(Game, dt){
  if(Game.paused) return;
  Game.timeToNextShot -= dt;
  // nearest in range
  let ni=-1, nd=Infinity; const range = Game.stats.range;
  for(let i=0;i<World.enemies.length;i++){
    const e = World.enemies[i]; if(!e.alive) continue;
    const d = Math.hypot(e.x-CX, e.y-CY);
    if(d<nd && d<=range){ nd=d; ni=i; }
  }
  if(ni>=0 && Game.timeToNextShot<=0){
    const e = World.enemies[ni];
    const dx=e.x-CX, dy=e.y-CY; const ang=Math.atan2(dy,dx);
    const spb = 1/Game.stats.firerate;
    const count = Math.max(1, Game.stats.multishot);
    for(let i=0;i<count;i++){
      const spread=(i-(count-1)/2)*0.09; const a=ang+spread;
      const vx=Math.cos(a)*Game.stats.projspd; const vy=Math.sin(a)*Game.stats.projspd;
      World.shots.push({x:CX, y:CY-8, vx, vy, damage:Game.stats.dmg, life:2.5, r:4, a:Math.atan2(vy,vx)});
    }
    Game.timeToNextShot = spb;
    Game.beepFire();
  }
  if(Game.alive && Game.stats.regen>0){
    Game.hp = clamp(Game.hp + Game.stats.regen*dt, 0, Game.hpMax);
  }
}

export function updateProjectiles(Game, dt){
  if(Game.paused) return;
  for(let i=World.shots.length-1;i>=0;i--){
    const p = World.shots[i];
    p.life -= dt; if(p.life<=0){ World.shots.splice(i,1); continue; }
    p.x += p.vx*dt; p.y += p.vy*dt; p.a = Math.atan2(p.vy,p.vx);
    // collision
    let hit=-1; let hd=16;
    for(let j=0;j<World.enemies.length;j++){
      const e=World.enemies[j]; if(!e.alive) continue;
      const d=Math.hypot(p.x-e.x, p.y-e.y); if(d<hd){ hit=j; hd=d; }
    }
    if(hit>=0){
      const e=World.enemies[hit]; e.hp -= p.damage;
      if(e.hp<=0){
        e.alive=false; World.enemies.splice(hit,1);
        Game.ryoRun += 3; // sync with CONFIG.ryo.kill
        Game.kills++;
        Game.flash(e.x,e.y,16,'#ff6b6b');
        Game.beepHit();
      } else {
        Game.flash(p.x,p.y,10,'#8be9fd');
      }
      if(Math.random()<Game.stats.splitChance){
        for(let k=0;k<2;k++){
          const a = p.a + (k?+0.35:-0.35);
          World.shots.push({x:p.x, y:p.y, vx:Math.cos(a)*Game.stats.projspd, vy:Math.sin(a)*Game.stats.projspd, damage:p.damage*0.6, life:0.9, r:4, a});
        }
      }
      World.shots.splice(i,1);
    }
  }
}

export function updateEnemies(Game, dt){
  if(Game.paused) return;
  const timeScale = Game.speed2 ? 2 : 1; dt *= timeScale;
  const dps = 8;
  for(let i=World.enemies.length-1;i>=0;i--){
    const e=World.enemies[i];
    const dx=CX-e.x, dy=CY-e.y; const dist=Math.hypot(dx,dy)||1;
    const ux=dx/dist, uy=dy/dist;
    e.x += ux*e.spd*dt; e.y += uy*e.spd*dt;
    if(dist<28){
      Game.hp -= dps*dt; Game.shake = Math.min(12, Game.shake + 0.6);
      if(Game.hp<=0){ Game.hp=0; Game.gameOver('Barrier destroyed'); return; }
    }
  }
}
