import { SAVE_KEY, META_DEFAULT } from './constants.js';
import { load, save } from './utils.js';

export let META = load(SAVE_KEY, structuredClone(META_DEFAULT));

export function persist(){ save(SAVE_KEY, META); }
export function resetMeta(){ META = structuredClone(META_DEFAULT); persist(); }
