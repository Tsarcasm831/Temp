import { META } from './state.js';
import { CONFIG } from './constants.js';
import { ensureAudio, beep, tone } from './audio.js';
import { now, rand } from './utils.js';
import { World } from './world.js';
import { render } from './render.js';
import { Waves } from './waves.js';
import { aimAndShoot, updateProjectiles, updateEnemies } from './combat.js';
import { wireUI, show, hide, setAssistUI, updateHUD, openShop, buildShop, showGameOver } from './ui.js';

const Game = {
  running:false, alive:true, wave:0, t:0, timeToNextShot:0, mode:'endless', timeLeft:0,
  ryoRun:0, stats:null, hp:0, hpMax:0, kills:0, speed2:false, paused:false, shake:0,
  start(mode){
    ensureAudio();
    this.mode = (mode===CONFIG.modes.TIMED || mode==='timed')? 'timed' : 'endless';
    this.running=true; this.alive=true; this.wave=0; this.t=0; this.ryoRun=0; this.kills=0; this.paused=false; this.shake=0;
    World.clear();
    this.stats = appliedStats();
    this.hpMax = this.stats.maxHP; this.hp = this.hpMax;
    this.timeLeft = (this.mode==='timed')? 180 : Infinity;
    updateHUD(this);
    beep(520,0.06,0.06);
  },
  end(){ this.running=false; this.alive=false; },
  updateHUD(){ updateHUD(this); },
  flash(x,y,r,color){ World.effects.push({x,y,r,life:0.2,color}); },
  beepHit(){ beep(700,0.03,0.04); },
  beepFire(){ beep(980,0.03,0.03); },
  gameOver(reason){ if(!this.alive) return; this.alive=false; this.end(); showGameOver(this, reason); tone(120,0.18,0.06,'sawtooth'); this.shake=10; }
};

import { appliedStats } from './balance.js';
window.addEventListener('keydown', (e)=>{
  if(e.code==='Space'){ Game.paused=!Game.paused; e.preventDefault(); }
  if(e.code==='KeyS'){ Game.speed2=!Game.speed2; }
  if(e.code==='KeyM'){ META.options.muted=!META.options.muted; }
});
window.addEventListener('pointerdown', ()=>ensureAudio(), {once:true});

let lastT = now(); let fpsAccum=0, fpsCount=0;

function frame(){
  const t = now(); let dt = (t - lastT)/1000; lastT = t; dt = Math.min(dt, 0.05);
  if(Game.running && Game.alive){
    if(!Game.paused){
      Game.t += dt;
      if(Game.mode==='timed'){ Game.timeLeft = Math.max(0, Game.timeLeft - dt); if(Game.timeLeft<=0){ Game.gameOver('Time Trial complete'); } }
      Waves.update(Game, dt);
      aimAndShoot(Game, dt);
      updateProjectiles(Game, dt);
      updateEnemies(Game, dt);
      // decay effects
      for(let i=World.effects.length-1;i>=0;i--){ const f=World.effects[i]; f.life-=dt; if(f.life<=0) World.effects.splice(i,1); }
    }
    render(Game, dt);
    updateHUD(Game);
  } else {
    render(Game, dt);
  }

  fpsAccum += 1/dt; fpsCount++;
  if(fpsCount>=15){
    const f = Math.round(fpsAccum/fpsCount);
    fpsAccum=0; fpsCount=0;
    const fpsEl = document.getElementById('ui-fps'); if(fpsEl) fpsEl.textContent=f;
  }
  requestAnimationFrame(frame);
}

import { appliedStats as _appliedStats } from './balance.js';
function appliedStats(){ return _appliedStats(); }

function init(){
  show(document.getElementById('menu'));
  buildShop(); updateHUD(Game); setAssistUI();
  // Background leaves init
  for(let i=0;i<24;i++){ World.leaves.push({x:Math.random()*innerWidth, y:Math.random()*innerHeight, r:Math.random()*4+3, s:Math.random()*12+6, a:Math.random()*Math.PI*2}); }
  frame();
}
wireUI(Game);
init();

// expose for tests
export { Game };
