export const clamp = (v,min,max)=>Math.min(max,Math.max(min,v));
export const lerp  = (a,b,t)=>a+(b-a)*t;
export const rand  = (a,b)=>a+Math.random()*(b-a);
export const now = ()=>performance.now();

export function roundedRect(ctx, x,y,w,h,r){
  r = Math.max(0, Math.min(r, Math.min(Math.abs(w), Math.abs(h)) / 2));
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y,     x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x,     y + h, r);
  ctx.arcTo(x,     y + h, x,     y,     r);
  ctx.arcTo(x,     y,     x + w, y,     r);
  ctx.closePath();
}

export const load = (k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch{return d}};
export const save = (k,v)=>localStorage.setItem(k,JSON.stringify(v));
