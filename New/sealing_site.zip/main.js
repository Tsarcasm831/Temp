
// Toggle answers/notes
document.addEventListener('click', (e)=>{
  const btn = e.target.closest('[data-toggle]');
  if(!btn) return;
  const id = btn.getAttribute('data-toggle');
  const tgt = document.getElementById(id);
  if(tgt){ tgt.style.display = (tgt.style.display==='block') ? 'none' : 'block'; }
});
