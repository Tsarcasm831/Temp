
// === Simple helpers for quizzes and smooth anchor scrolling ===
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-toggle]');
  if (btn){
    const id = btn.getAttribute('data-toggle');
    const target = document.getElementById(id);
    if (target){
      target.style.display = (target.style.display === 'block') ? 'none' : 'block';
    }
  }
});
