
registerGame('game-phase', {
  init(g){ g.state.phase=0; g.state.freq=1; },
  param(g,name,val){ if(name==='phase') g.state.phase = val*Math.PI/180; if(name==='freq') g.state.freq = Number(val); },
  update(g,dt){ 
    // nothing heavy
  },
  draw(g){
    const ctx=g.ctx, w=g.canvas.width, h=g.canvas.height; ctx.clearRect(0,0,w,h);
    const t=g.state.time;
    // samples
    let ys1=[], ys2=[];
    // target blue
    ctx.strokeStyle='#2e84ff'; ctx.lineWidth=2; ctx.beginPath();
    for(let x=0;x<w;x++){
      const tt = t + x/w*2;
      const f1 = 1 + 0.02*Math.sin(tt*0.7);
      const y1 = Math.sin(tt*2*Math.PI*f1);
      ys1.push(y1);
      const py1 = h*0.5 - y1*h*0.25;
      if(x===0) ctx.moveTo(x,py1); else ctx.lineTo(x,py1);
    } ctx.stroke();
    // user white
    ctx.strokeStyle='#dff6ff'; ctx.beginPath();
    for(let x=0;x<w;x++){
      const tt = t + x/w*2;
      const y2 = Math.sin((tt + g.state.phase/(2*Math.PI)) * 2*Math.PI * g.state.freq);
      ys2.push(y2);
      const py2 = h*0.5 - y2*h*0.25;
      if(x===0) ctx.moveTo(x,py2); else ctx.lineTo(x,py2);
    } ctx.stroke();
    // coherence
    let dot=0,a=0,b=0; for(let i=0;i<ys1.length;i++){ dot+=ys1[i]*ys2[i]; a+=ys1[i]*ys1[i]; b+=ys2[i]*ys2[i]; }
    const coh = Math.max(0, Math.min(1, dot / Math.sqrt(a*b+1e-6)));
    document.getElementById('phase-coh').textContent = Math.round(coh*100)+'%';
    document.getElementById('phase-err').textContent = (g.state.phase*180/Math.PI).toFixed(0)+'°';
    document.getElementById('phase-time').textContent = g.state.time.toFixed(1)+'s';
  }
});
