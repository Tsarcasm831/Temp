
registerGame('game-flow', {
  init(g){ g.state.throttle=0; g.state.out=0; g.state.k=0.08; g.state.drift=0.01; g.state.errSum=0; g.state.overs=0; },
  param(g,name,val){ if(name==='inertia') g.state.k = (100-val)/100 * 0.16 + 0.01; if(name==='drift') g.state.drift = val/100 * 0.03; },
  key(g,e){
    if(e.type==='keydown'){ if(e.code==='KeyA') g.state.throttle = clamp(g.state.throttle-0.04,0,1); if(e.code==='KeyD') g.state.throttle = clamp(g.state.throttle+0.04,0,1); }
  },
  update(g,dt){
    const target = 0.5 + 0.4*Math.sin(g.state.time*0.8) + 0.1*Math.sin(g.state.time*2.3);
    g.state.out += (g.state.throttle - g.state.out)*g.state.k - g.state.drift*dt;
    g.state.out = clamp(g.state.out,0,1);
    // error & overshoot
    g.state.errSum += Math.abs(target - g.state.out);
    if((g.state.prevErr||0)*(target - g.state.out) < -0.1) g.state.overs = (g.state.overs||0)+1;
    g.state.prevErr = (target - g.state.out);
    // HUD
    const t = g.state.time; document.getElementById('flow-time').textContent = t.toFixed(1)+'s';
    const acc = Math.max(0, 100 - (g.state.errSum/(t+0.001))*100); document.getElementById('flow-acc').textContent = Math.round(acc)+'%';
    document.getElementById('flow-over').textContent = g.state.overs||0;
  },
  draw(g){
    const ctx=g.ctx, w=g.canvas.width, h=g.canvas.height; ctx.clearRect(0,0,w,h);
    // Target line
    ctx.strokeStyle='#2e84ff'; ctx.lineWidth=2; ctx.beginPath();
    for(let x=0;x<w;x++){
      const t = (g.state.time + x/w*6); const target = 0.5 + 0.4*Math.sin(t*0.8) + 0.1*Math.sin(t*2.3);
      const y = h*(1 - target*0.8 - 0.1);
      if(x===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    } ctx.stroke();
    // Output
    ctx.strokeStyle='#7dff96'; ctx.beginPath(); const y = h*(1 - g.state.out*0.8 - 0.1); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke();
    // Throttle gauge
    ctx.fillStyle='rgba(125,255,150,0.18)'; ctx.fillRect(0,h-20,w*g.state.throttle,20);
  }
});
