
registerGame('game-partition', {
  init(g){
    g.state.share=[0.34,0.33,0.33]; g.state.dem=[0.4,0.4,0.4]; g.state.drops=0; g.state.errSum=0; g.state.chaos=0.2;
  },
  param(g,name,val){ if(name==='chaos') g.state.chaos = val/100; },
  key(g,e){
    if(e.type!=='keydown') return;
    const nudge=0.02; if(e.code==='Digit1') g.state.share[0]+=nudge;
    if(e.code==='Digit2') g.state.share[1]+=nudge;
    if(e.code==='Digit3') g.state.share[2]+=nudge;
    const s = Math.max(0.01, g.state.share[0]) + Math.max(0.01, g.state.share[1]) + Math.max(0.01, g.state.share[2]);
    g.state.share = g.state.share.map(v=>Math.max(0.01,v)/s);
  },
  update(g,dt){
    const c=g.state.chaos||0.2; const t=g.state.time;
    for(let i=0;i<3;i++){
      const base=0.35+0.2*Math.sin(t*(0.7+i*0.3)+i);
      const noise= c*0.2*Math.sin(t*(1.7+i*0.9)+i*1.7);
      g.state.dem[i]=clamp(base+noise,0.1,0.9);
    }
    const cap=1.0; const out=g.state.share.map(s=>s*cap);
    let err=0;
    g.state.badT = g.state.badT||[0,0,0];
    for(let i=0;i<3;i++){
      const e=Math.abs(out[i]-g.state.dem[i]); err+=e;
      if(e>0.15) g.state.badT[i]+=dt; else g.state.badT[i]=0;
      if(g.state.badT[i]>2){ g.state.drops++; g.state.badT[i]=0; }
    }
    g.state.errSum += err/3;
    // HUD
    const tnow = g.state.time;
    document.getElementById('part-time').textContent = tnow.toFixed(1)+'s';
    const acc = Math.max(0,100 - (g.state.errSum/(tnow+0.001))*120); document.getElementById('part-acc').textContent = Math.round(acc)+'%';
    document.getElementById('part-drops').textContent = g.state.drops||0;
  },
  draw(g){
    const ctx=g.ctx, w=g.canvas.width, h=g.canvas.height; ctx.clearRect(0,0,w,h);
    const tubeW=w/6, gap=w/12;
    for(let i=0;i<3;i++){
      const x = w/4 + i*(tubeW+gap);
      ctx.strokeStyle='#173052'; ctx.strokeRect(x,h*0.1,tubeW,h*0.8);
      ctx.fillStyle='rgba(118,255,207,0.12)';
      const d=g.state.dem[i]; ctx.fillRect(x,h*(1-(d+0.05))*0.8+ h*0.1,tubeW,h*0.8*0.1);
      const o=g.state.share[i];
      ctx.fillStyle='#7dff96'; ctx.fillRect(x, h*(1-o)*0.8 + h*0.1, tubeW, h*0.8*o);
    }
  }
});
