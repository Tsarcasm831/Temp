
registerGame('game-breath', { 
  init(g){
    g.state.tempo = 60; 
    g.state.window = 12*Math.PI/180; 
    g.state.hold=false; 
    g.state.holds=[]; 
    g.state.accTicks=0; 
    g.state.accGood=0;
  },
  param(g,name,val){
    if(name==='tempo') g.state.tempo = val;
    if(name==='window') g.state.window = val*Math.PI/180;
  },
  key(g,e){ 
    if(e.code==='Space'){ 
      e.preventDefault(); 
      if(e.type==='keydown') g.state.hold = true;
      if(e.type==='keyup') g.state.hold = false;
    } 
  },
  start(g){ g.state.holds=[]; g.state.accTicks=0; g.state.accGood=0; },
  stop(g){},
  update(g,dt){ },
  draw(g){
    const ctx = g.ctx, w=g.canvas.width, h=g.canvas.height;
    ctx.clearRect(0,0,w,h);
    const tempo = g.state.tempo; const T = 60/tempo;
    const t = g.state.time % T; const phi = (t/T)*2*Math.PI;
    // Target sine baseline
    ctx.strokeStyle = '#2e84ff'; ctx.lineWidth=2; ctx.beginPath();
    for(let x=0;x<w;x++){
      const tt = (x/w)*2*Math.PI;
      const y = h*0.5 - Math.sin(tt)*h*0.25;
      if(x===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.stroke();
    // Good window around π/2
    const win = g.state.window;
    const x1 = (Math.PI/2 - win)/(2*Math.PI)*w;
    const x2 = (Math.PI/2 + win)/(2*Math.PI)*w;
    ctx.fillStyle='rgba(118,255,207,0.18)'; ctx.fillRect(x1,0,(x2-x1),h);
    // Phase line
    const curx = (phi/(2*Math.PI))*w; ctx.strokeStyle='#7dff96'; ctx.beginPath(); ctx.moveTo(curx,0); ctx.lineTo(curx,h); ctx.stroke();
    // Score
    const good = (phi>Math.PI/2-win && phi<Math.PI/2+win);
    const holding = g.state.hold;
    g.state.accTicks += 1;
    if(holding && good) g.state.accGood += 1;
    const acc = Math.round((g.state.accGood)/(g.state.accTicks||1)*100);
    document.getElementById('breath-acc').textContent = acc + '%';
    document.getElementById('breath-stab').textContent = '—';
    document.getElementById('breath-time').textContent = g.state.time.toFixed(1)+'s';
    // Visual: bottom fill on hold
    if(holding){ ctx.fillStyle='rgba(125,255,150,0.18)'; ctx.fillRect(0,h*0.75,w,h*0.25); }
  }
});
