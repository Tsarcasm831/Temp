
// === Minimal Minigame Framework (multi-file) ===
const Games = {};
function registerGame(id, hooks){
  Games[id] = { hooks, running:false, last:0, state:{score:0, time:0, level:1}, canvas:null, ctx:null };
}
function attachGame(id){
  const el = document.getElementById(id);
  if(!el) return;
  const canvas = el.querySelector('canvas');
  const ctx = canvas.getContext('2d');
  const g = Games[id];
  g.canvas = canvas; g.ctx = ctx;
  if(g.hooks.init){ g.hooks.init(g); }
  el.querySelectorAll('[data-action]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const act = btn.getAttribute('data-action');
      if(act==='start'){ startGame(id); }
      if(act==='stop'){ stopGame(id); }
      if(act==='reset'){ resetGame(id); }
    });
  });
  el.querySelectorAll('input[type=range],select').forEach(inp=>{
    inp.addEventListener('input', ()=>{
      if(g.hooks.param) g.hooks.param(g, inp.name, Number(inp.value) || inp.value);
    });
  });
}
function startGame(id){
  const g = Games[id]; if(!g || g.running) return; g.running = true; g.last = performance.now();
  if(g.hooks.start) g.hooks.start(g);
  requestAnimationFrame(function loop(t){
    if(!g.running) return;
    const dt = (t - g.last)/1000; g.last = t; g.state.time += dt;
    if(g.hooks.update) g.hooks.update(g, dt);
    if(g.hooks.draw) g.hooks.draw(g);
    requestAnimationFrame(loop);
  });
}
function stopGame(id){ const g = Games[id]; if(g){ g.running=false; if(g.hooks.stop) g.hooks.stop(g);} }
function resetGame(id){ const g = Games[id]; if(!g) return; g.running=false; g.state={score:0,time:0,level:1}; if(g.hooks.init) g.hooks.init(g); if(g.hooks.draw) g.hooks.draw(g); }

document.addEventListener('DOMContentLoaded', ()=>{
  // Attach games declared before DOMContentLoaded
  Object.keys(Games).forEach(id => attachGame(id));
  // Also auto-attach any later-registered games after a small delay
  setTimeout(()=>{ Object.keys(Games).forEach(id => attachGame(id)); }, 50);
});
// Keyboard routing
window.addEventListener('keydown', (e)=>{
  Object.values(Games).forEach(g=>{ if(g.running && g.hooks.key){ g.hooks.key(g,e); } });
});
window.addEventListener('keyup', (e)=>{
  Object.values(Games).forEach(g=>{ if(g.running && g.hooks.key){ g.hooks.key(g,e); } });
});
// Utility
function clamp(v,min,max){ return Math.max(min, Math.min(max, v)); }
